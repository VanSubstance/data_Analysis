# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 20:28:20 2020

@author: sungh
"""

import pandas as pd

data_d = pd.read_csv('phase3\\' + 'leagues_d.csv')
data_c = pd.read_csv('phase3\\' + 'leagues_c.csv')
extractIndex = []

for player in data_c['name'].unique():
    indexes = data_c[data_c['name'] == player].index
    part = []
    parts = []
    for seq in range(len(indexes) - 1):
        if seq == len(indexes) - 2:
            part.append(indexes[seq + 1])
            parts.append(part)
            part = []
        if indexes[seq] == indexes[seq + 1]:
            part.append(indexes[seq])
        else:
            parts.append(part)
            part = []
            part.append(indexes[seq])
    